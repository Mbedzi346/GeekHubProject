#ifndef PASSENGERFACTORY_H
#define PASSENGERFACTORY_H

class PassengerFactory : PersonFactory {


public:
	Passenger* createPerson();
};

#endif
