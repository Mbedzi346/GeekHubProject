#ifndef PERSON_H
#define PERSON_H

class Person {
};

#endif
