#include "CrewFactory.h"

Person* CrewFactory::createPerson() {
	// TODO - implement CrewFactory::createPerson
	throw "Not yet implemented";
}
