#include "CommanderFactory.h"

Commander* CommanderFactory::createPerson() {
	// TODO - implement CommanderFactory::createPerson
	throw "Not yet implemented";
}
