#include "DoctorFactory.h"

Doctor* DoctorFactory::createPerson() {
	// TODO - implement DoctorFactory::createPerson
	throw "Not yet implemented";
}
