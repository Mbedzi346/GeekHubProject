#ifndef COMMANDER_H
#define COMMANDER_H

class Commander : CrewMember {
};

#endif
