#include "PFighterFactory.h"

Fighter* PFighterFactory::createPerson() {
	// TODO - implement PFighterFactory::createPerson
	throw "Not yet implemented";
}
