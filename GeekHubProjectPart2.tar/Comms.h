#ifndef COMMS_H
#define COMMS_H

class Comms : CrewMember {
};

#endif
