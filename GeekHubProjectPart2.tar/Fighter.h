#ifndef FIGHTER_H
#define FIGHTER_H

class Fighter : CrewMember {
};

#endif
