#ifndef NAVIGATORFACTORY_H
#define NAVIGATORFACTORY_H

class NavigatorFactory : CrewFactory {


public:
	Navigator* createPerson();
};

#endif
