#ifndef CREWFACTORY_H
#define CREWFACTORY_H

class CrewFactory : PersonFactory {


public:
	Person* createPerson();
};

#endif
