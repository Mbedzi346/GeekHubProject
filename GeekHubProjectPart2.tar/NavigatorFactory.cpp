#include "NavigatorFactory.h"

Navigator* NavigatorFactory::createPerson() {
	// TODO - implement NavigatorFactory::createPerson
	throw "Not yet implemented";
}
