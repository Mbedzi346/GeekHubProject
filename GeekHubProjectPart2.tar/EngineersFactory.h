#ifndef ENGINEERSFACTORY_H
#define ENGINEERSFACTORY_H

class EngineersFactory : CrewFactory {


public:
	Engineers* createPerson();
};

#endif
