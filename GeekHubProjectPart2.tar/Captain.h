#ifndef CAPTAIN_H
#define CAPTAIN_H

class Captain : CrewMember {
};

#endif
