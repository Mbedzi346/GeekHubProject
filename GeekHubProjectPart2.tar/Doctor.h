#ifndef DOCTOR_H
#define DOCTOR_H

class Doctor : CrewMember {
};

#endif
