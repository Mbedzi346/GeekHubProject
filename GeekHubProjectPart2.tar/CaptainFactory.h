#ifndef CAPTAINFACTORY_H
#define CAPTAINFACTORY_H

class CaptainFactory : CrewFactory {


public:
	Captain* createPerson();
};

#endif
