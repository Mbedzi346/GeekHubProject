#include "CommsFactory.h"

Comms* CommsFactory::createPerson() {
	// TODO - implement CommsFactory::createPerson
	throw "Not yet implemented";
}
