#ifndef CHIEF ENGINEER_H
#define CHIEF ENGINEER_H

class Chief_Engineer : CrewMember {
};

#endif
