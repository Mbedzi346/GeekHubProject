#include "PassengerFactory.h"

Passenger* PassengerFactory::createPerson() {
	// TODO - implement PassengerFactory::createPerson
	throw "Not yet implemented";
}
