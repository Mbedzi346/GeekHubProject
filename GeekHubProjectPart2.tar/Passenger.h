#ifndef PASSENGER_H
#define PASSENGER_H

class Passenger : Person {
};

#endif
