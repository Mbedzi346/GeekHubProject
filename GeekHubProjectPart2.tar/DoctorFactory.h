#ifndef DOCTORFACTORY_H
#define DOCTORFACTORY_H

class DoctorFactory : CrewFactory {


public:
	Doctor* createPerson();
};

#endif
