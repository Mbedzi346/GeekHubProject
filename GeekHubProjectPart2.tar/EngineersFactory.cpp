#include "EngineersFactory.h"

Engineers* EngineersFactory::createPerson() {
	// TODO - implement EngineersFactory::createPerson
	throw "Not yet implemented";
}
