#ifndef CHIEFENGINEERFACTORY_H
#define CHIEFENGINEERFACTORY_H

class ChiefEngineerFactory : CrewFactory {


public:
	CHiefEngineer* createPerson();
};

#endif
