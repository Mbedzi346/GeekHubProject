#ifndef CREWMEMBER_H
#define CREWMEMBER_H

class CrewMember : Person {
};

#endif
