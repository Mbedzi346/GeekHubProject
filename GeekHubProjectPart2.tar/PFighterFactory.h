#ifndef PFIGHTERFACTORY_H
#define PFIGHTERFACTORY_H

class PFighterFactory : CrewFactory {


public:
	Fighter* createPerson();
};

#endif
