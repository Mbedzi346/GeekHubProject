#include "ChiefEngineerFactory.h"

CHiefEngineer* ChiefEngineerFactory::createPerson() {
	// TODO - implement ChiefEngineerFactory::createPerson
	throw "Not yet implemented";
}
