#ifndef FRIGATES_H
#define FRIGATES_H
#include "Spaceship.h"
class Frigates: public Spaceship{
    
};
#endif