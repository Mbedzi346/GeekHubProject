#include "CaptainFactory.h"

Captain* CaptainFactory::createPerson() {
	// TODO - implement CaptainFactory::createPerson
	throw "Not yet implemented";
}
