#ifndef COMMSFACTORY_H
#define COMMSFACTORY_H

class CommsFactory : CrewFactory {


public:
	Comms* createPerson();
};

#endif
