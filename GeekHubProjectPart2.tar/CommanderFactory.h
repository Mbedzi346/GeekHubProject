#ifndef COMMANDERFACTORY_H
#define COMMANDERFACTORY_H

class CommanderFactory : CrewFactory {


public:
	Commander* createPerson();
};

#endif
