#ifndef NAVIGATOR_H
#define NAVIGATOR_H

class Navigator : CrewMember {
};

#endif
