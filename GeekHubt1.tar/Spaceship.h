#ifndef SPACESHIP_H
#define SPACESHIP_H
class Spaceship{
    private:
        double displacement;
        double power;
        double speed;
        double thrust;
        double maxSpeed;
        double stallSpeed;
        int crew;
        int passengers;
    public:
        
};
#endif