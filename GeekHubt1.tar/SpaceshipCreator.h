//
// Created by Orifha Mbedzi on 2019-09-28.
//

#ifndef GEEKHUBPROJECT_SPACESHIPCREATOR_H
#define GEEKHUBPROJECT_SPACESHIPCREATOR_H

class Spaceship;
class SpaceshipCreator {
private:
    int cat;
public:
    Spaceship* createSpaceship();

};


#endif //GEEKHUBPROJECT_SPACESHIPCREATOR_H
