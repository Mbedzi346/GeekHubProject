#ifndef EXPLORATION_H
#define EXPLORATION_H
#include "Spaceship.h"
class Exploration: public Spaceship{
    
};
#endif